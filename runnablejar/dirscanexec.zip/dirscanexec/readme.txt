Directory Scanner

Program scan the specified directory, 
and copies the files that meet a certain condition 
in the output directory.

Available 5 commands:

scan    Scan the specified directory and copies files that meet a certain condition in to the output directory
        Parameters:
        -inputDir            Input Directory (required)",
        -outputDir           Output Directory (required)",
	-mask                Mask for files to be copied (required)",
        -waitInterval        Interval with which the scanner scans the specified directory (required)",
        -includeSubFolders   Or may not include the processing of subdirectories (not required)",
        -autoDelete          Delete or not delete, the files after copying (not required)",
        Example: scan -inputDir c:/test/in -outputDir c:/test/out -mask *.* -waitInterval 30000 -includeSubFolders true -autoDelete false"

info    Provides information about running processes.         

help    Provides Help information

stop    Stop scan process by Id.",
        parameter:   id of running thread
 	Example: stop 1252356

exit    Quits the DirectoryScanner program."
